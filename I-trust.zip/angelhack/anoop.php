<?php
@mysql_connect("localhost","root","")or die("problem");//same as try and catch in java
mysql_select_db("angan");
?>